/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.project2;

/**
 *
 * @author adiwi
 */
public class Project2 {

    public static void main(String[] args) {
       void ganti() {
    if (isOn) {
        System.out.println("Menyalakan lampu");
        System.out.println("Menyalakan lampu lain");
    }
}