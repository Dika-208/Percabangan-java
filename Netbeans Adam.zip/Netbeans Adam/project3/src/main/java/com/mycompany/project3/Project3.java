/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.project3;

/**
 *
 * @author adiwi
 */
public class Project3 {

    public static void main(String[] args) {
        boolean isOn = false;


        if (isOn) {
            System.out.println("Menyalakan lampu");
        } else {
            System.out.println("Kondisi tidak terpenuhi...");
        }
    }
}

